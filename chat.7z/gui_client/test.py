from jim import *

msg = MessageSent.message(user_key='Matt', msg='@Claire Bourne Hello!')
print(msg)
